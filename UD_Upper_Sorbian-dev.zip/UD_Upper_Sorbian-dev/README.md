# Summary

A small treebank of Upper Sorbian based mostly on Wikipedia.


# Introduction

The Upper Sorbian sentences are taken from the W2C corpus (Martin Majliš), which
was further manually filtered, morphologically and syntactically annotated by
Dan Zeman; lemmatization by Anna Nedoluzhko.

Sentences in the W2C corpus are shuffled.


=== Machine-readable metadata (DO NOT REMOVE!) ================================
Data available since: UD v2.1
License: CC BY-SA 4.0
Includes text: yes
Genre: wiki nonfiction
Lemmas: manual native
UPOS: manual native
XPOS: manual native
Features: manual native
Relations: manual native
Contributors: Zeman, Daniel; Nedoluzhko, Anna
Contributing: here
Contact: zeman@ufal.mff.cuni.cz
===============================================================================
